import threading
import tkinter as tk
import threading
from tkinter import StringVar, TOP, Text, BOTTOM
from tkinterdnd2 import TkinterDnD, DND_ALL
import customtkinter as ctk
import serial.tools.list_ports
from datetime import datetime
import time
import sys
import serial
import zlib
import os
import struct


class Tk(ctk.CTk, TkinterDnD.DnDWrapper):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.TkdndVersion = TkinterDnD._require(self)

ctk.set_appearance_mode("dark")

connected_ports = set()  # Set to store connected ports
ser = None  # Serial connection object
ack_number = None
campo_sync = "U*U*U*U*"
numero_sequencia = 1
endereco_destino = 2
endereco_origem = 1
lock = threading.Lock()
running = True
sending_message = False
type_received = None
last_sent = None

ack_condition = threading.Condition()


def read_acks():
    global ack_number, type_received, last_sent
    global running
    while running:
        if ser:
            ser.read(ser.in_waiting)
            ack = bytes()
            ack += ser.read(2)
            print(ack.decode(errors='ignore'))
            print("Character received:", chr(ack[0]))
            print("Integer received:", int(ack[1]))
            type_received = chr(ack[0])
            if type_received == "2":
                ack_number = last_sent #caso receba uma mensagem para retransmitir o ultimo pacote enviado (devido a excesso de NACKS, avisar esse pacote)
                                       #last_sent foi criada para caso o numero de sequencia no pacote fosse corrompido também
            else:
                ack_number = int(ack[1])

            with ack_condition:
                ack_condition.notify_all()

        else:
            time.sleep(0.2)

def send_packet_l2(payload, tamanho_real_payload):
    global numero_sequencia
    # Add the overhead bytes to the payload
    overhead_bytes = bytes([numero_sequencia, endereco_origem, endereco_destino, tamanho_real_payload])
    byte_buffer = campo_sync.encode() + overhead_bytes + payload
    byte_buffer += calculate_crc32(byte_buffer)
    # Send the current packet
    send_packet(byte_buffer)

def send_packet(packet_bytes):
    if ser:
        ser.read(ser.inWaiting())
        while ser.out_waiting > 0:
            pass
        ser.reset_output_buffer()
        ser.write(packet_bytes)
        ser.flush()

        print("\nMessage sent: " + str(packet_bytes.decode(errors='ignore')))
        print("Message size: " + str(len(packet_bytes)))

    else:
        log_message("Serial connection not initialized!")


def get_and_send_file_thread(event):
    path = event.data.replace("{", "").replace("}", "")
    filename = os.path.basename(path).split('/')[-1]
    t2 = threading.Thread(target=lambda: get_and_send_file(path, filename))
    t2.start()
    textWidget.delete(0, tk.END)


def get_and_send_file(path, filename):
    with open(path, 'rb') as file:
        file_data = file.read()
        byte_buffer = bytearray(file_data)
        # Process the byte buffer as needed
    num_payloads = (len(byte_buffer) // 127) + 1

    global ack_number, sending_message, type_received, last_sent
    global numero_sequencia
    global running
    sent = False

    if ser:
        lock.acquire()
        try:
            while not sent:
                # envio de flag "init" para identificar o inicio do envio de uma mensagem (1 para mensagens,
                # 2 para ficheiros)
                current_payload = "2".encode() + filename.encode()
                tamanho_real_payload = len(current_payload)

                send_packet_l2(current_payload, tamanho_real_payload)
                last_sent = numero_sequencia
                log_message(f"Payload 1/{num_payloads + 2} sent")
                with ack_condition:
                    while ack_number != numero_sequencia and running:
                        ack_condition.wait()  # Wait until notified
                    if type_received != 2:
                        sent = True
                        log_message(f"Response received: ACK {ack_number}")
                        increment_sequence_number()

            
        finally:
            lock.release()

        try:
            for i in range(num_payloads):
                while(sending_message):
                    time.sleep(0.2)
                    pass
                lock.acquire()

                try:
                    sent = False
                    while not sent:
                        # Calculate the start and end indices for the current payload
                        start_index = i * 127
                        end_index = min(start_index + 127, len(byte_buffer))  # Adjusted end_index

                        # Cria o payload para o pacote
                        # "3" identifica o tipo de dados, neste caso mensagem de chat --> protocolo de aplicação
                        # "1" -> flag init chat, "2" -> flag init ficheiro, "3" -> trama de mensagem de chat
                        # "4" -> trama de ficheiro, "5" -> flag fim chat, "6" -> flag fim ficheiro
                        current_payload = "4".encode() + byte_buffer[start_index:end_index]
                        tamanho_real_payload = len(current_payload)

                        send_packet_l2(current_payload, tamanho_real_payload)

                        last_sent = numero_sequencia
                        log_message(f"Payload {i + 2}/{num_payloads+2} sent")

                        # Wait for the ack before following through
                        with ack_condition:
                            while ack_number != numero_sequencia and running:
                                ack_condition.wait()  # Wait until notified
                            if type_received != 2:
                                sent = True
                                log_message(f"Response received: ACK {ack_number}")
                                increment_sequence_number()

                finally:
                    lock.release()

            lock.acquire()
            try:
                sent = False
                while not sent:
                    # envio de flag "fim" para identificar o inicio do envio de uma mensagem (5 para mensagens, 6 para ficheiros)
                    current_payload = "6".encode()
                    tamanho_real_payload = len(current_payload)
                    send_packet_l2(current_payload, tamanho_real_payload)

                    last_sent = numero_sequencia

                    log_message(f"Payload {num_payloads + 2}/{num_payloads + 2} sent")

                    with ack_condition:
                        while ack_number != numero_sequencia and running:
                            ack_condition.wait()  # Wait until notified
                        if type_received != 2:
                            sent = True
                            log_message(f"Response received: ACK {ack_number}")
                            increment_sequence_number()
            finally:
                lock.release()

        except serial.SerialException:
            log_message("Failed to send message!")
    else:
        log_message("Serial connection not initialized!")

def send_message_thread(event):
    message = textWidget.get()
    t1 = threading.Thread(target=lambda: send_message(message))
    t1.start()
    textWidget.delete(0, tk.END)

def send_message(message):
    message_bytes = message.encode()
    # Calculate the number of payloads required
    num_payloads = (len(message_bytes) // 127) + 1
    global ack_number, last_sent
    global numero_sequencia
    global sending_message
    sending_message = True
    sent = False
    if ser:
        lock.acquire()
        try:
            while not sent:
                #envio de flag "init" para identificar o inicio do envio de uma mensagem (1 para mensagens, 2 para ficheiros)
                current_payload = "1".encode()
                tamanho_real_payload = len(current_payload)
                send_packet_l2(current_payload, tamanho_real_payload)
                last_sent = numero_sequencia
                log_message(f"Payload 1/{num_payloads + 2} sent: {current_payload.decode()}")
                with ack_condition:
                    while ack_number != numero_sequencia and running:
                        ack_condition.wait()  # Wait until notified
                    if type_received != 2:
                        sent = True
                        log_message(f"Response received: ACK {ack_number}")
                        increment_sequence_number()

            
        finally:
            lock.release()

        try:
            for i in range(num_payloads):
                lock.acquire()

                try:
                    sent = False
                    while not sent:
                        # Calculate the start and end indices for the current payload
                        start_index = i * 127
                        end_index = min(start_index + 127, len(message_bytes))  # Adjusted end_index

                        # Cria o payload para o pacote
                        # "3" identifica o tipo de dados, neste caso mensagem de chat --> protocolo de aplicação
                        # "1" -> flag init chat, "2" -> flag init ficheiro, "3" -> trama de mensagem de chat
                        # "4" -> trama de ficheiro, "5" -> flag fim chat, "6" -> flag fim ficheiro
                        current_payload = "3".encode() + message_bytes[start_index:end_index]
                        tamanho_real_payload = len(current_payload)

                        send_packet_l2(current_payload, tamanho_real_payload)
                        last_sent = numero_sequencia

                        log_message(f"Payload {i + 2}/{num_payloads+2} sent: {current_payload.decode()}")

                        # Wait for the ack before following through
                        with ack_condition:
                            while ack_number != numero_sequencia and running:
                                ack_condition.wait()  # Wait until notified
                            if type_received != 2:
                                sent = True
                                log_message(f"Response received: ACK {ack_number}")
                                increment_sequence_number()

                finally:
                    lock.release()

            lock.acquire()
            try:
                sent = False
                while not sent:
                    # envio de flag "fim" para identificar o inicio do envio de uma mensagem (1 para mensagens, 2 para ficheiros)
                    current_payload = "5".encode()
                    tamanho_real_payload = len(current_payload)
                    send_packet_l2(current_payload, tamanho_real_payload)
                    last_sent = numero_sequencia

                    log_message(f"Payload {num_payloads + 2}/{num_payloads + 2} sent")

                    # Wait for the ack before following through
                    with ack_condition:
                        while ack_number != numero_sequencia and running:
                            ack_condition.wait()  # Wait until notified
                        if type_received != 2:
                            sent = True
                            log_message(f"Response received: ACK {ack_number}")
                            increment_sequence_number()
            finally:
                lock.release()
                sending_message = False

        except serial.SerialException:
            log_message("Failed to send message!")
    else:
        log_message("Serial connection not initialized!")


def calculate_crc32(data):
    crc32_result = zlib.crc32(data)
    return crc32_result.to_bytes(4)

def increment_sequence_number():
    global numero_sequencia
    numero_sequencia += 1
    if numero_sequencia == 250:
        numero_sequencia = 1

def on_entry_click(event):
    if textWidget.get() == 'Type here to send message':
        textWidget.delete(0, tk.END)
        textWidget.configure(text_color='white')  # Change text color to black

def on_focus_out(event):
    if not textWidget.get():
        textWidget.insert(0, 'Type here to send message')
        textWidget.configure(text_color='gray')  # Change text color to gray

def update_ports():
    global connected_ports
    ports = {port.device for port in serial.tools.list_ports.comports()}
    new_ports = ports - connected_ports
    for port in new_ports:
        log_message(f"COM Port {port} Initialized!")
    disconnected_ports = connected_ports - ports
    for port in disconnected_ports:
        log_message(f"COM Port {port} Disconnected!")
    connected_ports = ports

    if ports:
        port_list.configure(values=list(ports))
    else:
        port_list.configure(values=["No ports found"])

    root.after(1000, update_ports)
    check_selected_port()  # Call the check_selected_port() function

def check_selected_port():
    selected_port = port_list.get()
    if selected_port != "Select COM" and selected_port != "No ports found" and selected_port in connected_ports:
        try:
            global ser
            if ser:
                ser.close()
            ser = serial.Serial(selected_port, baudrate=9600, stopbits=serial.STOPBITS_ONE, parity=serial.PARITY_NONE, bytesize=serial.EIGHTBITS)
            ser.reset_input_buffer()



            log_message(f"Serial connection initialized on {selected_port}!")
        except serial.SerialException as e:
            log_message(f"Failed to initialize serial connection on {selected_port}! Error: {str(e)}")
        port_list.set("Select COM")
    root.after(1000, check_selected_port)

def log_message(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    console_text.configure(state='normal')
    console_text.insert('end', f'{timestamp} ', 'timestamp')
    console_text.insert('end', f'> {message}\n', 'message')
    console_text.configure(state='disabled')
    console_text.see('end')

    with open('log_file.txt', 'a') as log_file:
        log_file.write(f'{timestamp} > {message}\n')

def close_serial(ser):
    if ser:
        ser.close()
        log_message("Serial connection closed.")
    global running
    running = False
    with ack_condition:
        ack_condition.notify_all()
    root.destroy()

root = Tk()
root.geometry("600x600")
root.title("Transmitter")

nameVar = StringVar()

port_list = ctk.CTkComboBox(root)
port_list.configure(state='readonly')
port_list.set("Select COM")
port_list.pack(side=TOP, padx=5, pady=20)

entryWidget = ctk.CTkEntry(root)
textWidget = ctk.CTkEntry(root,width=580, text_color="grey")
textWidget.pack(side=BOTTOM, padx=5, pady=10)
textWidget.insert(0, 'Type here to send message')
textWidget.bind('<FocusIn>', on_entry_click)
textWidget.bind('<FocusOut>', on_focus_out)
textWidget.bind('<Return>', send_message_thread)  # Bind the send_message function to the Return key press event

pathLabel = ctk.CTkLabel(root, text="",padx=0, pady=0,height=0, width=0)
pathLabel.pack(side=TOP)

console_text = Text(root, height=70, width=90, wrap='word', state='disabled', bg='black', fg='gray')
console_text.tag_configure('timestamp', foreground='green')
console_text.tag_configure('message', foreground='white')
console_text.pack(side=TOP)

log_message("Application started.")
#entryWidget.drop_target_register(DND_ALL)
#entryWidget.dnd_bind("<<Drop>>", get_and_send_file)

# Enable drag and drop functionality for the log area
console_text.drop_target_register(DND_ALL)
console_text.dnd_bind("<<Drop>>", get_and_send_file_thread)
update_ports()
check_selected_port()  # Call the check_selected_port() function before starting the main event loop

t_acks = threading.Thread(target=read_acks)
t_acks.start()

root.protocol("WM_DELETE_WINDOW", lambda: close_serial(ser))

root.mainloop()