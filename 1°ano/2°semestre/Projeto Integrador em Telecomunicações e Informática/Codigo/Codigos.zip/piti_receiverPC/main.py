import os
import time
import tkinter as tk
import threading
from tkinter import StringVar, TOP, Text, BOTTOM
from tkinterdnd2 import TkinterDnD, DND_ALL
import customtkinter as ctk
import serial.tools.list_ports
from datetime import datetime
import sys
import serial
import zlib


class Tk(ctk.CTk, TkinterDnD.DnDWrapper):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.TkdndVersion = TkinterDnD._require(self)


ctk.set_appearance_mode("dark")

connected_ports = set()  # Set to store connected ports
ser = None  # Serial connection object
campo_sync = "U*U*U*U*"
running = True
nome_ficheiro = ""
mensagem = ""
file = None
time_init_mensagem = None
time_init_ficheiro = None
def readSerial():
    global running, nome_ficheiro, file, time_init_ficheiro, time_init_mensagem
    global mensagem
    while running:
        if ser:
            ser.read(ser.in_waiting)
            while True:
                if ser.in_waiting > 0:
                    byte_array = bytes()
                    byte_array += ser.read(12)  # lê os bytes do cabeçalho
                    tamanho_payload = int(byte_array[11])
                    byte_array += ser.read(tamanho_payload + 4)  # lê o payload + 4bytes de CRC
                    print("Mensagem Recebida: " + str(byte_array.decode(errors='ignore')))
                    print("Tamanho Payload: " + str(tamanho_payload))
                    print("Tipo Mensagem: " + chr(byte_array[12]))
                    print("Tamanho Mensagem: " + str(len(byte_array)))
                    if verify_crc(byte_array):
                        match chr(byte_array[12]):
                            case "1":
                                mensagem = ""
                                time_init_mensagem = time.time()
                                log_message(f"Mensagem a ser transmitida")
                                send_ack_nack(awnser=1, data=byte_array)

                            case "2":
                                nome_ficheiro = byte_array[13:tamanho_payload + 12].decode()
                                file = open(nome_ficheiro, 'wb')
                                time_init_ficheiro = time.time()
                                log_message(f"Ficheiro a ser transmitido")
                                send_ack_nack(awnser=1, data=byte_array)

                            case "3":
                                mensagem += byte_array[13:tamanho_payload + 12].decode()
                                # log_message(f"Trama de mensagem recebida")
                                send_ack_nack(awnser=1, data=byte_array)

                            case "4":
                                file.write(byte_array[13:tamanho_payload + 12])
                                file.flush()
                                os.fsync(file.fileno())
                                # log_message(f"Trama de ficheiro recebida")
                                send_ack_nack(awnser=1, data=byte_array)

                            case "5":
                                log_message(f"Mensagem recebida: {mensagem} --> tempo total: {time.time()-time_init_mensagem:.3f}")
                                send_ack_nack(awnser=1, data=byte_array)

                            case "6":
                                log_message(f"Ficheiro recebido: {nome_ficheiro} --> tempo total: {time.time()-time_init_ficheiro:.3f}")
                                send_ack_nack(awnser=1, data=byte_array)
                                file.close()
        else:
            time.sleep(0.5)


t_read = threading.Thread(target=readSerial)
t_read.start()


def verify_crc(data):
    if calculate_crc32(data[:-4]) == data[-4:]:  # se o crc recebido e o calculado forem iguais
        return True
    else:
        send_ack_nack(awnser=0, data=data)
        return False


def send_ack_nack(awnser, data):
    resposta = bytearray()
    if awnser == 1:  # se o crc recebido e o calculado forem iguais
        resposta += "1".encode()  # manda um ack
        resposta += int(data[8]).to_bytes(1)  # adiciona o numero sequencia ao ack
        ser.write(resposta)
        ser.flush()
        print("ACK " + str(int(data[8])))
        print("\n")
        return True
    else:
        resposta += "0".encode()  # manda um nack
        resposta += int(data[8]).to_bytes(1)  # adiciona o numero sequencia ao nack
        ser.write(resposta)
        ser.flush()
        print("NACK")
        print("\n")
        return False


def calculate_crc32(data):
    crc32_result = zlib.crc32(data)
    return crc32_result.to_bytes(4)


def update_ports():
    global connected_ports
    ports = {port.device for port in serial.tools.list_ports.comports()}
    new_ports = ports - connected_ports
    for port in new_ports:
        log_message(f"COM Port {port} Initialized!")
    disconnected_ports = connected_ports - ports
    for port in disconnected_ports:
        log_message(f"COM Port {port} Disconnected!")
    connected_ports = ports

    if ports:
        port_list.configure(values=list(ports))
    else:
        port_list.configure(values=["No ports found"])

    root.after(1000, update_ports)
    check_selected_port()  # Call the check_selected_port() function


def check_selected_port():
    selected_port = port_list.get()
    if selected_port != "Select COM" and selected_port != "No ports found" and selected_port in connected_ports:
        try:
            global ser
            if ser:
                ser.close()
            ser = serial.Serial(selected_port, baudrate=9600, stopbits=serial.STOPBITS_ONE, parity=serial.PARITY_NONE,
                                bytesize=serial.EIGHTBITS)
            ser.reset_input_buffer()
            log_message(f"Serial connection initialized on {selected_port}!")
        except serial.SerialException as e:
            log_message(f"Failed to initialize serial connection on {selected_port}! Error: {str(e)}")
        port_list.set("Select COM")
    root.after(1000, check_selected_port)


def log_message(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    console_text.configure(state='normal')
    console_text.insert('end', f'{timestamp} ', 'timestamp')
    console_text.insert('end', f'> {message}\n', 'message')
    console_text.configure(state='disabled')
    console_text.see('end')

    with open('log_file.txt', 'a') as log_file:
        log_file.write(f'{timestamp} > {message}\n')


def close_serial(ser):
    if ser:
        global running
        ser.close()
        log_message("Serial connection closed.")
    running = False
    root.destroy()


root = Tk()
root.geometry("600x600")
root.title("Receiver")

nameVar = StringVar()

port_list = ctk.CTkComboBox(root)
port_list.configure(state='readonly')
port_list.set("Select COM")
port_list.pack(side=TOP, padx=5, pady=20)

entryWidget = ctk.CTkEntry(root)

pathLabel = ctk.CTkLabel(root, text="", padx=0, pady=0, height=0, width=0)
pathLabel.pack(side=TOP)

console_text = Text(root, height=70, width=90, wrap='word', state='disabled', bg='black', fg='gray')
console_text.tag_configure('timestamp', foreground='green')
console_text.tag_configure('message', foreground='white')
console_text.pack(side=TOP)

log_message("Application started.")

update_ports()
check_selected_port()  # Call the check_selected_port() function before starting the main event loop

root.protocol("WM_DELETE_WINDOW", lambda: close_serial(ser))
root.mainloop()
